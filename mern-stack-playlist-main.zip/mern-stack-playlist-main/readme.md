# Welcome Our Mern Stack Series


```bash
        npm i

```
```bash
    npm run start
```