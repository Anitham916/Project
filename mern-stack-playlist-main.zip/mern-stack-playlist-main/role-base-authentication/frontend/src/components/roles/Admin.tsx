import React from 'react'

const Admin = () => {
  return (
    <>Admin</>
  )
}

export default Admin